from django.urls import path
from .views import TaskListView, TaskCreateView, TaskUpdateView, TaskDeleteView
from .api import TaskListAPI
from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),          # Admin panel
    path('', include('tasks.urls')),         # Link to the tasks app
    path('', TaskListView.as_view(), name='task-list'),
    path('create/', TaskCreateView.as_view(), name='task-create'),
    path('<int:pk>/update/', TaskUpdateView.as_view(), name='task-update'),
    path('<int:pk>/delete/', TaskDeleteView.as_view(), name='task-delete'),
    path('api/tasks/', TaskListAPI.as_view(), name='api-task-list'),
]
