from django import forms
from .models import Task
import datetime  # Import datetime module

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'priority', 'status', 'due_date']

    def clean_due_date(self):
        due_date = self.cleaned_data.get('due_date')
        if due_date < datetime.date.today():  # Check if due_date is in the past
            raise forms.ValidationError("Due date cannot be in the past.")
        return due_date
